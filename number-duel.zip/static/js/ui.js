/**
 * UI Renderer and DOM Component Manipulator.
 */

function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.setAttribute("role", "status");

  const icon = type === "error" ? "⚠️" : type === "success" ? "✅" : "ℹ️";
  toast.innerHTML = `<span>${icon}</span> <span>${escapeHtml(message)}</span>`;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(-10px)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function escapeHtml(text) {
  if (!text) return "";
  const map = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" };
  return text.toString().replace(/[&<>"']/g, m => map[m]);
}

class UIRenderer {
  constructor() {
    this.currentStage = null;
    this.activeHistoryTab = "my"; // 'my' or 'opp'
    this.cachedState = null;
  }

  render(state, myPlayerId) {
    this.cachedState = state;
    const me = state.player_1?.player_id === myPlayerId ? state.player_1 : state.player_2;
    const opponent = state.player_1?.player_id === myPlayerId ? state.player_2 : state.player_1;

    // 1. Header Information
    const codeEl = document.getElementById("display-game-code");
    if (codeEl) codeEl.textContent = state.game_code || "------";

    const shareInput = document.getElementById("share-link-input");
    if (shareInput) {
      const shareUrl = `${window.location.origin}/?join=${state.game_code}`;
      shareInput.value = shareUrl;
    }

    // 2. Player Cards
    this.renderPlayerCards(state, myPlayerId, me, opponent);

    // 3. Secret HUD (Always shows my private secret number safely)
    this.renderSecretHUD(me, state);

    // 4. Game Stages & Turn Banner
    this.renderStages(state, myPlayerId, me, opponent);

    // 5. History
    this.renderHistory(state, myPlayerId);

    // 6. Chat Messages
    this.renderChatMessages(state.chat_messages, myPlayerId);
  }

  renderPlayerCards(state, myPlayerId, me, opponent) {
    // Player 1
    const p1 = state.player_1;
    const p1Card = document.getElementById("p1-card");
    const p1Name = document.getElementById("p1-name");
    const p1Pill = document.getElementById("p1-status-pill");
    const p1Length = document.getElementById("p1-length-badge");
    const p1Ready = document.getElementById("p1-ready-badge");

    if (p1) {
      p1Name.textContent = p1.name + (p1.player_id === myPlayerId ? " (You)" : "");
      p1Pill.textContent = p1.connected ? "Online" : "Disconnected";
      p1Pill.className = `status-pill ${p1.connected ? "online" : ""}`;
      p1Length.textContent = p1.number_length ? `${p1.number_length} Digits` : "Choosing...";
      p1Ready.textContent = p1.ready ? "Locked In" : "Pending";
      p1Ready.style.color = p1.ready ? "var(--color-green)" : "var(--text-muted)";
    } else {
      p1Name.textContent = "Waiting for Player 1...";
      p1Pill.textContent = "Offline";
      p1Length.textContent = "—";
      p1Ready.textContent = "Pending";
    }

    // Player 2
    const p2 = state.player_2;
    const p2Card = document.getElementById("p2-card");
    const p2Name = document.getElementById("p2-name");
    const p2Pill = document.getElementById("p2-status-pill");
    const p2Length = document.getElementById("p2-length-badge");
    const p2Ready = document.getElementById("p2-ready-badge");

    if (p2) {
      p2Name.textContent = p2.name + (p2.player_id === myPlayerId ? " (You)" : "");
      p2Pill.textContent = p2.connected ? "Online" : "Disconnected";
      p2Pill.className = `status-pill ${p2.connected ? "online" : ""}`;
      p2Length.textContent = p2.number_length ? `${p2.number_length} Digits` : "Choosing...";
      p2Ready.textContent = p2.ready ? "Locked In" : "Pending";
      p2Ready.style.color = p2.ready ? "var(--color-green)" : "var(--text-muted)";
    } else {
      p2Name.textContent = "Waiting for Player 2...";
      p2Pill.textContent = "Offline";
      p2Length.textContent = "—";
      p2Ready.textContent = "Pending";
    }

    // Active turn highlight
    if (state.current_turn) {
      p1Card?.classList.toggle("active-turn", state.current_turn === p1?.player_id);
      p2Card?.classList.toggle("active-turn", state.current_turn === p2?.player_id);
    } else {
      p1Card?.classList.remove("active-turn");
      p2Card?.classList.remove("active-turn");
    }
  }

  renderSecretHUD(me, state) {
    const hud = document.getElementById("my-secret-display");
    if (!hud) return;

    const secret = state.my_secret_number;
    if (secret) {
      hud.innerHTML = secret
        .split("")
        .map(ch => `<div class="hud-digit">${escapeHtml(ch)}</div>`)
        .join("");
    } else if (me?.number_length) {
      hud.innerHTML = Array(me.number_length)
        .fill(0)
        .map(() => `<div class="hud-digit" style="opacity:0.35">?</div>`)
        .join("");
    } else {
      hud.innerHTML = `<span class="digit-placeholder">— Not Chosen Yet —</span>`;
    }
  }

  renderStages(state, myPlayerId, me, opponent) {
    const status = state.status;
    const banner = document.getElementById("turn-banner");
    const bannerIcon = document.getElementById("banner-icon");
    const bannerTitle = document.getElementById("banner-title");
    const bannerSub = document.getElementById("banner-sub");

    // Hide all stage sections first
    const stages = ["stage-waiting", "stage-length", "stage-secret", "stage-duel", "stage-victory"];
    stages.forEach(id => document.getElementById(id)?.classList.add("hidden"));

    // 1. WAITING FOR PLAYER 2
    if (status === "WAITING_FOR_PLAYER") {
      document.getElementById("stage-waiting")?.classList.remove("hidden");
      banner.className = "turn-banner banner-waiting";
      bannerIcon.textContent = "⏳";
      bannerTitle.textContent = "Waiting for Player 2 to join...";
      bannerSub.textContent = "Share your invite link or code to begin the match.";
      return;
    }

    // 2. CHOOSING NUMBER LENGTH
    if (status === "CHOOSING_NUMBER_LENGTH" || status === "PLAYER_2_JOINED") {
      document.getElementById("stage-length")?.classList.remove("hidden");
      banner.className = "turn-banner banner-waiting";
      bannerIcon.textContent = "⚙️";
      bannerTitle.textContent = "Choose Your Number Length";
      bannerSub.textContent = "Pick between 3 to 6 digits for your secret number.";

      const lengthWaiting = document.getElementById("length-waiting-note");
      if (me?.number_length) {
        lengthWaiting?.classList.remove("hidden");
        document.querySelectorAll(".length-btn").forEach(btn => {
          btn.classList.toggle("selected", parseInt(btn.dataset.length) === me.number_length);
        });
      } else {
        lengthWaiting?.classList.add("hidden");
      }
      return;
    }

    // 3. WAITING FOR SECRET NUMBERS
    if (status === "WAITING_FOR_SECRET_NUMBERS" || (me && !me.ready)) {
      document.getElementById("stage-secret")?.classList.remove("hidden");
      banner.className = "turn-banner banner-waiting";
      bannerIcon.textContent = "🔒";
      bannerTitle.textContent = "Lock In Your Secret Number";
      bannerSub.textContent = `Enter a ${me?.number_length || 4}-digit number to lock in.`;

      document.getElementById("chosen-length-text").textContent = me?.number_length || 4;

      const secretWaiting = document.getElementById("secret-waiting-note");
      if (me?.ready) {
        secretWaiting?.classList.remove("hidden");
      } else {
        secretWaiting?.classList.add("hidden");
      }
      return;
    }

    // 4. DUEL IN PROGRESS: TURNS
    if (status === "PLAYER_1_TURN" || status === "PLAYER_2_TURN" || status === "READY") {
      document.getElementById("stage-duel")?.classList.remove("hidden");

      const isMyTurn = state.is_my_turn;
      const targetLen = state.required_guess_length || 4;

      document.getElementById("target-length-count").textContent = targetLen;
      const turnBadge = document.getElementById("turn-indicator-badge");

      if (isMyTurn) {
        banner.className = "turn-banner banner-your-turn";
        bannerIcon.textContent = "🎯";
        bannerTitle.textContent = "YOUR TURN TO GUESS";
        bannerSub.textContent = `Submit a ${targetLen}-digit guess to test opponent's secret number!`;

        if (turnBadge) {
          turnBadge.className = "turn-indicator-badge turn-active";
          turnBadge.textContent = "YOUR TURN";
        }
      } else {
        const oppName = opponent ? opponent.name : "Opponent";
        banner.className = "turn-banner banner-opponent-turn";
        bannerIcon.textContent = "⏳";
        bannerTitle.textContent = `Waiting for ${oppName}...`;
        bannerSub.textContent = `${oppName} is currently analyzing and submitting a guess.`;

        if (turnBadge) {
          turnBadge.className = "turn-indicator-badge turn-waiting";
          turnBadge.textContent = "OPPONENT'S TURN";
        }
      }
      return;
    }

    // 5. GAME WON
    if (status === "GAME_WON") {
      document.getElementById("stage-victory")?.classList.remove("hidden");
      banner.className = "turn-banner banner-your-turn";
      bannerIcon.textContent = "🏆";

      const winnerId = state.winner;
      const winnerName = (winnerId === me?.player_id) ? me.name : (opponent ? opponent.name : "Winner");
      const isWinner = (winnerId === myPlayerId);

      bannerTitle.textContent = `${winnerName.toUpperCase()} WON THE MATCH!`;
      bannerSub.textContent = isWinner ? "Sensational tactical victory! You cracked their number!" : "Good effort! Rematch to reclaim the title.";

      document.getElementById("victory-title").textContent = `${winnerName.toUpperCase()} WON!`;
      document.getElementById("victory-subtitle").textContent = isWinner
        ? "Flawless deduction! You completely cracked the secret code!"
        : "Opponent cracked your secret number first. Ready for revenge?";

      const oppSecret = opponent?.secret_number || "—";
      document.getElementById("revealed-opponent-secret").textContent = oppSecret;
      document.getElementById("revealed-turns-count").textContent = state.turn_count || 1;
    }
  }

  renderHistory(state, myPlayerId) {
    const list = document.getElementById("guess-list-container");
    const myCount = document.getElementById("my-guess-count");
    const oppCount = document.getElementById("opp-guess-count");
    if (!list) return;

    const myGuesses = state.my_guesses || [];
    const oppGuesses = state.opponent_guesses || [];

    if (myCount) myCount.textContent = myGuesses.length;
    if (oppCount) oppCount.textContent = oppGuesses.length;

    const activeList = this.activeHistoryTab === "my" ? myGuesses : oppGuesses;

    if (activeList.length === 0) {
      list.innerHTML = `<div class="empty-history-text">No guesses in this tab yet.</div>`;
      return;
    }

    list.innerHTML = activeList
      .slice()
      .reverse()
      .map(g => {
        const badgesHtml = g.result
          .map((res, idx) => {
            const isGreen = res === "GREEN";
            const accessibleLabel = isGreen
              ? `Digit ${idx + 1}: Correct value and position`
              : `Digit ${idx + 1}: Incorrect value or position`;
            return `
              <span class="result-badge ${isGreen ? 'badge-green' : 'badge-red'}"
                    title="${accessibleLabel}"
                    aria-label="${accessibleLabel}">
                ${isGreen ? '🟢' : '🔴'}
              </span>
            `;
          })
          .join("");

        return `
          <div class="guess-item">
            <div class="guess-item-left">
              <span class="guess-num">#${g.turn_number}</span>
              <span class="guess-val">${escapeHtml(g.guess_value)}</span>
            </div>
            <div class="guess-results-row">
              ${badgesHtml}
            </div>
          </div>
        `;
      })
      .join("");
  }

  renderChatMessages(messages, myPlayerId) {
    const container = document.getElementById("chat-messages-container");
    if (!container || !messages) return;

    const wasAtBottom = container.scrollHeight - container.scrollTop <= container.clientHeight + 50;

    container.innerHTML = messages
      .map(m => {
        if (m.is_system) {
          return `<div class="system-chat-msg">${escapeHtml(m.message)}</div>`;
        }
        const isSelf = m.player_id === myPlayerId;
        const timeStr = m.timestamp ? new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : "";
        return `
          <div class="chat-bubble ${isSelf ? 'msg-self' : 'msg-peer'}">
            ${!isSelf ? `<div class="msg-sender">${escapeHtml(m.player_name)}</div>` : ''}
            <div class="msg-text">${escapeHtml(m.message)}</div>
            <div class="msg-time">${timeStr}</div>
          </div>
        `;
      })
      .join("");

    if (wasAtBottom) {
      container.scrollTop = container.scrollHeight;
    }
  }

  setTyping(name, isTyping) {
    const el = document.getElementById("typing-indicator-text");
    if (!el) return;
    if (isTyping && name) {
      el.textContent = `${name} is typing...`;
    } else {
      el.textContent = "";
    }
  }
}

const ui = new UIRenderer();
