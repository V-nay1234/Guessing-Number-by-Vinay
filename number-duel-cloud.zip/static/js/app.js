/**
 * Main Game Controller: State Management, Events, User Interactions, and Flow.
 */

class AppController {
  constructor() {
    this.session = null; // { game_id, game_code, player_id, session_token }
    this.gameState = null;
    this.webrtc = null;

    // Buffer for entering Secret Number
    this.secretInputDigits = [];
    this.selectedLength = null;

    // Buffer for entering Guess
    this.guessInputDigits = [];

    // Typing debounce
    this.typingTimer = null;
    this.isTypingSent = false;
  }

  async init() {
    this.webrtc = new WebRTCManager(gameSocket);
    this.initSocketEvents();
    this.bindEvents();
    this.checkUrlForInvite();
    this.checkStoredSession();
  }

  // 1. Initial URL inspection (e.g. ?join=AB7K92 or /game/AB7K92)
  checkUrlForInvite() {
    const urlParams = new URLSearchParams(window.location.search);
    const joinCode = urlParams.get("join");
    if (joinCode) {
      const codeInput = document.getElementById("join-code-input");
      if (codeInput) {
        codeInput.value = joinCode.toUpperCase();
      }
    }
  }

  // 2. Persistent Session Inspection
  checkStoredSession() {
    try {
      const raw = localStorage.getItem("number_duel_session");
      if (raw) {
        const stored = JSON.parse(raw);
        if (stored.game_id && stored.player_id && stored.session_token) {
          this.session = stored;
          const banner = document.getElementById("resume-banner");
          const codeText = document.getElementById("resume-code-text");
          if (banner && codeText) {
            codeText.textContent = stored.game_code || "";
            banner.classList.remove("hidden");
          }
        }
      }
    } catch (e) {
      console.warn("Could not check local storage session:", e);
    }
  }

  saveSession(sessionData) {
    this.session = sessionData;
    localStorage.setItem("number_duel_session", JSON.stringify(sessionData));
  }

  clearSession() {
    this.session = null;
    localStorage.removeItem("number_duel_session");
  }

  // 3. WebSocket Event Registration
  initSocketEvents() {
    gameSocket.onStatusChange((status, text) => {
      const badge = document.getElementById("connection-badge");
      const textEl = document.getElementById("connection-text");
      if (badge && textEl) {
        badge.className = `connection-badge status-${status}`;
        textEl.textContent = text;
      }
    });

    gameSocket.on("STATE_UPDATE", (data) => {
      this.gameState = data;
      ui.render(data, this.session?.player_id);
      this.syncPinBoxes();
    });

    gameSocket.on("CHAT_MESSAGE", (msg) => {
      if (this.gameState) {
        this.gameState.chat_messages.push(msg);
        ui.renderChatMessages(this.gameState.chat_messages, this.session?.player_id);
      }
    });

    gameSocket.on("TYPING_STATUS", (data) => {
      ui.setTyping(data.player_name, data.is_typing);
    });

    gameSocket.on("ERROR", (err) => {
      showToast(err.message || "An error occurred.", "error");
    });
  }

  // 4. Bind DOM and Keyboard Events
  bindEvents() {
    // Create Game
    document.getElementById("create-game-btn")?.addEventListener("click", () => this.handleCreateGame());

    // Join Game
    document.getElementById("join-game-btn")?.addEventListener("click", () => this.handleJoinGame());

    // Rejoin from banner
    document.getElementById("resume-btn")?.addEventListener("click", () => this.handleResumeGame());
    document.getElementById("discard-session-btn")?.addEventListener("click", () => {
      this.clearSession();
      document.getElementById("resume-banner")?.classList.add("hidden");
    });

    // Copy Code & Invite Link
    document.getElementById("copy-code-btn")?.addEventListener("click", () => {
      if (this.gameState?.game_code) {
        navigator.clipboard.writeText(this.gameState.game_code);
        showToast("Room code copied to clipboard!", "success");
      }
    });

    document.getElementById("copy-link-btn")?.addEventListener("click", () => {
      this.copyInviteLink();
    });

    document.getElementById("copy-share-input-btn")?.addEventListener("click", () => {
      this.copyInviteLink();
    });

    // Leave Game
    document.getElementById("leave-game-btn")?.addEventListener("click", () => {
      if (confirm("Are you sure you want to leave this duel?")) {
        gameSocket.disconnect();
        this.clearSession();
        window.location.href = "/";
      }
    });

    // Length Selection Buttons (3, 4, 5, 6)
    document.querySelectorAll(".length-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const length = parseInt(btn.dataset.length);
        this.handleSelectLength(length);
      });
    });

    // Secret Keypad buttons
    document.querySelectorAll("#stage-secret .key-btn[data-key]").forEach(btn => {
      btn.addEventListener("click", () => this.handleSecretKey(btn.dataset.key));
    });
    document.getElementById("secret-del-btn")?.addEventListener("click", () => this.handleSecretDelete());
    document.getElementById("secret-clear-btn")?.addEventListener("click", () => this.handleSecretClear());
    document.getElementById("submit-secret-btn")?.addEventListener("click", () => this.handleSubmitSecret());

    // Guess Keypad buttons
    document.querySelectorAll("#stage-duel .guess-key[data-key]").forEach(btn => {
      btn.addEventListener("click", () => this.handleGuessKey(btn.dataset.key));
    });
    document.getElementById("guess-del-btn")?.addEventListener("click", () => this.handleGuessDelete());
    document.getElementById("guess-clear-btn")?.addEventListener("click", () => this.handleGuessClear());
    document.getElementById("submit-guess-btn")?.addEventListener("click", () => this.handleSubmitGuess());

    // Physical Keyboard navigation
    document.addEventListener("keydown", (e) => this.handlePhysicalKeyboard(e));

    // Guess History Tabs
    document.getElementById("tab-my-guesses")?.addEventListener("click", () => {
      ui.activeHistoryTab = "my";
      document.getElementById("tab-my-guesses")?.classList.add("active");
      document.getElementById("tab-opp-guesses")?.classList.remove("active");
      if (this.gameState) ui.renderHistory(this.gameState, this.session?.player_id);
    });

    document.getElementById("tab-opp-guesses")?.addEventListener("click", () => {
      ui.activeHistoryTab = "opp";
      document.getElementById("tab-opp-guesses")?.classList.add("active");
      document.getElementById("tab-my-guesses")?.classList.remove("active");
      if (this.gameState) ui.renderHistory(this.gameState, this.session?.player_id);
    });

    // Rematch & New Game
    document.getElementById("rematch-btn")?.addEventListener("click", () => {
      gameSocket.send("REMATCH", {});
    });

    document.getElementById("new-game-btn")?.addEventListener("click", () => {
      this.clearSession();
      window.location.href = "/";
    });

    // Chat Form Submit
    document.getElementById("chat-form")?.addEventListener("submit", (e) => {
      e.preventDefault();
      this.handleSendChat();
    });

    // Chat Typing listener
    const chatInput = document.getElementById("chat-input");
    chatInput?.addEventListener("input", () => this.handleTyping());

    // Emoji Picker Toggle
    const emojiToggle = document.getElementById("emoji-toggle-btn");
    const emojiPicker = document.getElementById("emoji-picker");
    const emojiGrid = document.getElementById("emoji-grid");

    if (emojiToggle && emojiPicker && emojiGrid) {
      initEmojiPicker(emojiPicker, emojiGrid, (emoji) => {
        if (chatInput) {
          chatInput.value += emoji;
          chatInput.focus();
        }
      });

      emojiToggle.addEventListener("click", (e) => {
        e.stopPropagation();
        emojiPicker.classList.toggle("hidden");
      });

      document.addEventListener("click", (e) => {
        if (!emojiPicker.contains(e.target) && e.target !== emojiToggle) {
          emojiPicker.classList.add("hidden");
        }
      });
    }

    // WebRTC Buttons
    document.getElementById("webrtc-call-btn")?.addEventListener("click", () => {
      this.webrtc.requestCall("video");
    });

    document.getElementById("webrtc-audio-btn")?.addEventListener("click", () => {
      this.webrtc.requestCall("audio");
    });

    document.getElementById("toggle-mic-btn")?.addEventListener("click", () => {
      this.webrtc.toggleMicrophone();
    });

    document.getElementById("toggle-cam-btn")?.addEventListener("click", () => {
      this.webrtc.toggleCamera();
    });

    document.getElementById("hangup-call-btn")?.addEventListener("click", () => {
      this.webrtc.endCall(true);
    });
  }

  copyInviteLink() {
    if (this.gameState?.game_code) {
      const shareUrl = `${window.location.origin}/?join=${this.gameState.game_code}`;
      navigator.clipboard.writeText(shareUrl);
      showToast("Invite link copied to clipboard! Send it to your friend.", "success");
    }
  }

  // 5. Create Game Request
  async handleCreateGame() {
    const nameInput = document.getElementById("player-name-input");
    const name = nameInput?.value.trim() || "Vinay";

    try {
      const res = await fetch("/api/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ player_name: name })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Could not create game.");
      }

      const data = await res.json();
      this.saveSession({
        game_id: data.game_id,
        game_code: data.game_code,
        player_id: data.player_id,
        session_token: data.session_token
      });

      this.enterGameRoom();
    } catch (err) {
      showToast(err.message, "error");
    }
  }

  // 6. Join Game Request
  async handleJoinGame() {
    const nameInput = document.getElementById("player-name-input");
    const codeInput = document.getElementById("join-code-input");
    const name = nameInput?.value.trim() || "Player";
    const code = codeInput?.value.trim().toUpperCase();

    if (!code || code.length < 4) {
      showToast("Please enter a valid game code.", "error");
      return;
    }

    try {
      const res = await fetch("/api/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ game_code: code, player_name: name })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Could not join game.");
      }

      const data = await res.json();
      this.saveSession({
        game_id: data.game_id,
        game_code: data.game_code,
        player_id: data.player_id,
        session_token: data.session_token
      });

      this.enterGameRoom();
    } catch (err) {
      showToast(err.message, "error");
    }
  }

  // 7. Resume Existing Session
  async handleResumeGame() {
    if (!this.session) return;
    try {
      const res = await fetch("/api/reconnect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          game_id: this.session.game_id,
          player_id: this.session.player_id,
          session_token: this.session.session_token
        })
      });

      if (!res.ok) {
        this.clearSession();
        document.getElementById("resume-banner")?.classList.add("hidden");
        throw new Error("Previous session expired or invalid.");
      }

      this.enterGameRoom();
    } catch (err) {
      showToast(err.message, "error");
    }
  }

  enterGameRoom() {
    document.getElementById("lobby-screen")?.classList.add("hidden");
    document.getElementById("game-container")?.classList.remove("hidden");

    // Connect WebSocket
    gameSocket.connect(this.session.game_id, this.session.player_id, this.session.session_token);
  }

  // 8. Length Selection
  handleSelectLength(length) {
    this.selectedLength = length;
    gameSocket.send("SELECT_LENGTH", { length });
  }

  // 9. Secret Number Entry
  handleSecretKey(digit) {
    const me = this.gameState?.player_1?.player_id === this.session?.player_id ? this.gameState?.player_1 : this.gameState?.player_2;
    const maxLen = me?.number_length || this.selectedLength || 4;

    if (this.secretInputDigits.length < maxLen) {
      this.secretInputDigits.push(digit);
      this.syncPinBoxes();
    }
  }

  handleSecretDelete() {
    if (this.secretInputDigits.length > 0) {
      this.secretInputDigits.pop();
      this.syncPinBoxes();
    }
  }

  handleSecretClear() {
    this.secretInputDigits = [];
    this.syncPinBoxes();
  }

  handleSubmitSecret() {
    const me = this.gameState?.player_1?.player_id === this.session?.player_id ? this.gameState?.player_1 : this.gameState?.player_2;
    const requiredLen = me?.number_length || this.selectedLength || 4;

    if (this.secretInputDigits.length !== requiredLen) {
      showToast(`Secret number must have exactly ${requiredLen} digits.`, "error");
      return;
    }

    const secretStr = this.secretInputDigits.join("");
    gameSocket.send("SUBMIT_SECRET", { secret_number: secretStr });
  }

  // 10. Guess Entry
  handleGuessKey(digit) {
    if (!this.gameState?.is_my_turn) {
      showToast("It is not your turn to guess.", "info");
      return;
    }

    const requiredLen = this.gameState?.required_guess_length || 4;
    if (this.guessInputDigits.length < requiredLen) {
      this.guessInputDigits.push(digit);
      this.syncPinBoxes();
    }
  }

  handleGuessDelete() {
    if (this.guessInputDigits.length > 0) {
      this.guessInputDigits.pop();
      this.syncPinBoxes();
    }
  }

  handleGuessClear() {
    this.guessInputDigits = [];
    this.syncPinBoxes();
  }

  handleSubmitGuess() {
    if (!this.gameState?.is_my_turn) {
      showToast("It is not your turn.", "error");
      return;
    }

    const requiredLen = this.gameState?.required_guess_length || 4;
    if (this.guessInputDigits.length !== requiredLen) {
      showToast(`Guess must contain exactly ${requiredLen} digits.`, "error");
      return;
    }

    const guessStr = this.guessInputDigits.join("");
    this.guessInputDigits = [];
    this.syncPinBoxes();

    gameSocket.send("SUBMIT_GUESS", { guess: guessStr });
  }

  // 11. Sync PIN boxes with current input buffers
  syncPinBoxes() {
    // Secret PIN boxes
    const secretRow = document.getElementById("secret-pin-boxes");
    const me = this.gameState?.player_1?.player_id === this.session?.player_id ? this.gameState?.player_1 : this.gameState?.player_2;
    const secretLen = me?.number_length || this.selectedLength || 4;

    if (secretRow) {
      secretRow.innerHTML = "";
      for (let i = 0; i < secretLen; i++) {
        const box = document.createElement("div");
        box.className = "pin-box";
        if (i < this.secretInputDigits.length) {
          box.textContent = this.secretInputDigits[i];
          box.classList.add("filled");
        } else if (i === this.secretInputDigits.length) {
          box.classList.add("active-box");
        }
        secretRow.appendChild(box);
      }
    }

    const submitSecretBtn = document.getElementById("submit-secret-btn");
    if (submitSecretBtn) {
      submitSecretBtn.disabled = this.secretInputDigits.length !== secretLen || (me && me.ready);
    }

    // Guess PIN boxes
    const guessRow = document.getElementById("guess-pin-boxes");
    const targetLen = this.gameState?.required_guess_length || 4;

    if (guessRow) {
      guessRow.innerHTML = "";
      for (let i = 0; i < targetLen; i++) {
        const box = document.createElement("div");
        box.className = "pin-box";
        if (i < this.guessInputDigits.length) {
          box.textContent = this.guessInputDigits[i];
          box.classList.add("filled");
        } else if (i === this.guessInputDigits.length && this.gameState?.is_my_turn) {
          box.classList.add("active-box");
        }
        guessRow.appendChild(box);
      }
    }

    const submitGuessBtn = document.getElementById("submit-guess-btn");
    if (submitGuessBtn) {
      submitGuessBtn.disabled = 
        !this.gameState?.is_my_turn || 
        this.guessInputDigits.length !== targetLen ||
        this.gameState?.status === "GAME_WON";
    }
  }

  // 12. Physical Keyboard Support
  handlePhysicalKeyboard(e) {
    // If user is focused on chat input, don't intercept digits
    if (document.activeElement?.id === "chat-input" || document.activeElement?.id === "player-name-input" || document.activeElement?.id === "join-code-input") {
      return;
    }

    const status = this.gameState?.status;

    // Number keys 0-9
    if (/^[0-9]$/.test(e.key)) {
      e.preventDefault();
      if (status === "WAITING_FOR_SECRET_NUMBERS" || (status === "CHOOSING_NUMBER_LENGTH" && this.selectedLength)) {
        this.handleSecretKey(e.key);
      } else if (status === "PLAYER_1_TURN" || status === "PLAYER_2_TURN") {
        this.handleGuessKey(e.key);
      }
    } else if (e.key === "Backspace" || e.key === "Delete") {
      e.preventDefault();
      if (status === "WAITING_FOR_SECRET_NUMBERS" || (status === "CHOOSING_NUMBER_LENGTH" && this.selectedLength)) {
        this.handleSecretDelete();
      } else if (status === "PLAYER_1_TURN" || status === "PLAYER_2_TURN") {
        this.handleGuessDelete();
      }
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (status === "WAITING_FOR_SECRET_NUMBERS") {
        this.handleSubmitSecret();
      } else if (status === "PLAYER_1_TURN" || status === "PLAYER_2_TURN") {
        this.handleSubmitGuess();
      }
    }
  }

  // 13. Chat Actions
  handleSendChat() {
    const input = document.getElementById("chat-input");
    const text = input?.value.trim();
    if (!text) return;

    gameSocket.send("SEND_CHAT", { message: text });
    input.value = "";

    // Clear typing
    if (this.isTypingSent) {
      gameSocket.send("TYPING", { is_typing: false });
      this.isTypingSent = false;
    }
  }

  handleTyping() {
    if (!this.isTypingSent) {
      gameSocket.send("TYPING", { is_typing: true });
      this.isTypingSent = true;
    }
    clearTimeout(this.typingTimer);
    this.typingTimer = setTimeout(() => {
      gameSocket.send("TYPING", { is_typing: false });
      this.isTypingSent = false;
    }, 2500);
  }
}

// Start app on DOMContentLoaded
window.addEventListener("DOMContentLoaded", () => {
  const app = new AppController();
  app.init();
});
